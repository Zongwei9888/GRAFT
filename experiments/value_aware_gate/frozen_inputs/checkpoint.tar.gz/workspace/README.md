# JSON Lines delta aggregator

`aggregate.py` reads UTF-8 JSON Lines from standard input and sums integer
`delta` values by string `key`. Blank lines are ignored. The result is written
as one compact JSON object with lexicographically sorted keys.

## Usage

```sh
printf '%s\n' \
  '{"key":"oranges","delta":2}' \
  '{"key":"apples","delta":3}' \
  '{"key":"oranges","delta":-1}' \
  | python3 aggregate.py
```

Output:

```json
{"apples":3,"oranges":1}
```

Each nonblank input line must be a JSON object containing exactly `key` and
`delta`. `key` must be a string and `delta` must be an integer (JSON booleans
are rejected). Invalid input produces one error line on standard error, no
standard output, and exit status 2.

## Tests

```sh
python3 -m unittest -v
```
