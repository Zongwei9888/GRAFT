import json
from pathlib import Path
import subprocess
import sys
import unittest


PROGRAM = Path(__file__).with_name("aggregate.py")


def run_aggregate(input_data):
    return subprocess.run(
        [sys.executable, str(PROGRAM)],
        input=input_data,
        capture_output=True,
        check=False,
    )


class AggregateTests(unittest.TestCase):
    def test_sums_deltas_and_sorts_keys(self):
        result = run_aggregate(
            b'{"key":"z","delta":2}\n'
            b'{"key":"a","delta":4}\n'
            b'{"key":"z","delta":-1}\n'
        )

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b'{"a":4,"z":1}\n')
        self.assertEqual(result.stderr, b"")

    def test_ignores_blank_lines_and_supports_utf8(self):
        result = run_aggregate(
            ' \n\t\n{"key":"é","delta":3}\n'.encode("utf-8")
        )

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.decode("utf-8"), '{"é":3}\n')

    def test_empty_input_outputs_empty_object(self):
        result = run_aggregate(b"")

        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, b"{}\n")

    def test_rejects_each_invalid_input_without_stdout(self):
        invalid_inputs = {
            "malformed JSON": b'{"key":\n',
            "non-object": b'[]\n',
            "missing field": b'{"key":"a"}\n',
            "extra field": b'{"key":"a","delta":1,"x":2}\n',
            "non-string key": b'{"key":1,"delta":2}\n',
            "non-integer delta": b'{"key":"a","delta":1.5}\n',
            "boolean delta": b'{"key":"a","delta":true}\n',
            "invalid UTF-8": b'\xff\n',
        }

        for label, input_data in invalid_inputs.items():
            with self.subTest(label):
                result = run_aggregate(input_data)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b"")
                self.assertRegex(result.stderr.decode("utf-8"), r"^error: .+\n$")
                self.assertEqual(result.stderr.count(b"\n"), 1)

    def test_error_after_valid_records_still_writes_no_stdout(self):
        result = run_aggregate(
            b'{"key":"a","delta":1}\n{"key":"b","delta":false}\n'
        )

        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b"")


if __name__ == "__main__":
    unittest.main()
