#!/usr/bin/env python3
"""Aggregate integer deltas from JSON Lines read on standard input."""

import json
import sys


def fail(message: str) -> "None":
    print(f"error: {message}", file=sys.stderr)
    raise SystemExit(2)


def main() -> None:
    totals: dict[str, int] = {}

    try:
        for line_number, line in enumerate(sys.stdin, start=1):
            if not line.strip():
                continue

            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                fail(f"invalid JSON on line {line_number}")

            if not isinstance(record, dict):
                fail(f"line {line_number} is not an object")
            if set(record) != {"key", "delta"} or len(record) != 2:
                fail(f"line {line_number} must contain only key and delta")

            key = record["key"]
            delta = record["delta"]
            if not isinstance(key, str):
                fail(f"key on line {line_number} must be a string")
            if isinstance(delta, bool) or not isinstance(delta, int):
                fail(f"delta on line {line_number} must be an integer")

            totals[key] = totals.get(key, 0) + delta
    except UnicodeError:
        fail("input is not valid UTF-8")

    json.dump(totals, sys.stdout, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
